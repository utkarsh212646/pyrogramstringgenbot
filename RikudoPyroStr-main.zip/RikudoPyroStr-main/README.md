# RikudoPyroStr

[![deploy](https://telegra.ph/file/4f3dee3a87e98d9b6a901.jpg)](https://heroku.com/deploy?template=https://github.com/AvikaTrivedi/RikudoPyroStr)

👆👆
YOU Can click on above Image to deploy 
________

Generate Pyrogram String Session Using this bot.

## Bot Link:
<a href="https://t.me/pyrogram_string_genrobot"><img src="https://img.shields.io/badge/Telegram-Bot-blue.svg?logo=telegram"></a>

## Configs:
- API_HASH
  - Get from [Here](https://my.telegram.org).
- API_ID
  - Get from [Here](https://my.telegram.org).
- API_KEY
  - Heroku API Key from [Here](https://dashboard.heroku.com/account).
- APP_NAME
  - Heroku App Name.
- BOT_TOKEN
  - Telegram Bot Token from [here](https://t.me/BotFather).

## Deploy Now:
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/AvikaTrivedi/RikudoPyroStr)


#### Developers
- [Avika](https://t.me/avika_5555)
- [satyanand](https://t.me/satyanandatripathi)

Love u guys😉💗
